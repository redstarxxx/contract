import { useState, useEffect } from "react";
import { ethers } from "ethers";

// 合约地址与 ABI（请替换为真实值）
const contractAddress = "0xCa76f47033eBbcaA2F077f9415335025efB82282";
const abi = [
  "function addNote(string _note) public",
  "function getNotes() public view returns (string[] memory)"
];

function App() {
  const [note, setNote] = useState("");
  const [notes, setNotes] = useState([]);
  const [contract, setContract] = useState(null);

  useEffect(() => {
    const init = async () => {
      if (window.ethereum) {
        await window.ethereum.request({ method: "eth_requestAccounts" });
        const provider = new ethers.BrowserProvider(window.ethereum);
        const signer = await provider.getSigner();
        const instance = new ethers.Contract(contractAddress, abi, signer);
        setContract(instance);
        const data = await instance.getNotes();
        setNotes(data);
      }
    };
    init();
  }, []);

  const handleAdd = async () => {
    if (note && contract) {
      const tx = await contract.addNote(note);
      await tx.wait();
      const data = await contract.getNotes();
      setNotes(data);
      setNote("");
    }
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={styles.title}>📝 区块链记事本</h2>
        <div style={styles.inputGroup}>
          <input
            style={styles.input}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="记录你的一句话..."
          />
          <button style={styles.button} onClick={handleAdd}>提交</button>
        </div>
        <ul style={styles.noteList}>
          {notes.map((n, i) => (
            <li key={i} style={styles.noteItem}>📌 {n}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

const styles = {
  wrapper: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f7f9fb",
    fontFamily: "'Segoe UI', sans-serif",
  },
  card: {
    backgroundColor: "#fff",
    padding: "40px",
    borderRadius: "16px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
    width: "90%",
    maxWidth: "500px",
  },
  title: {
    marginBottom: "20px",
    textAlign: "center",
    color: "#333",
  },
  inputGroup: {
    display: "flex",
    marginBottom: "20px",
    gap: "10px",
  },
  input: {
    flex: 1,
    padding: "12px",
    fontSize: "16px",
    borderRadius: "8px",
    border: "1px solid #ccc",
    outline: "none",
  },
  button: {
    padding: "12px 20px",
    fontSize: "16px",
    borderRadius: "8px",
    backgroundColor: "#007bff",
    color: "#fff",
    border: "none",
    cursor: "pointer",
  },
  noteList: {
    listStyle: "none",
    padding: 0,
    margin: 0,
  },
  noteItem: {
    padding: "10px",
    backgroundColor: "#f1f1f1",
    marginBottom: "8px",
    borderRadius: "6px",
    color: "#333",
  },
};

export default App;
